Level = {
	board : {
		0: {type: 'Chip', color:'Blue', x: 1, y: 2},
		1: {type: 'Chip', color:'Yellow', x: 5, y: 5},
		2: {type: 'Chip', color:'Red', x: 0, y: 3},
		4: {type: 'Chip', color:'Red', x: 2, y: 3},
		5: {type: 'Chip', color:'Red', x: 4, y: 4},
		6: {type: 'Chip', color:'Red', x: 6, y: 4},
		8: {type: 'Bishop', color:'Blue', x: 2, y: 0},
		9: {type: 'Bishop', color:'Yellow', x: 2, y: 7},
	},
	name: '2 Spieler - Läufer - Level 7',
	description: 'Erreiche deinen Chip als erster!',
	win : 2
}
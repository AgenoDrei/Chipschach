Level = {
	board : {
		0: {type: 'Chip', color:'Blue', x: 2, y: 4},
		1: {type: 'Chip', color:'Blue', x: 3, y: 3},
		2: {type: 'Chip', color:'Blue', x: 4, y: 2},
		3: {type: 'Chip', color:'Blue', x: 5, y: 1},
		4: {type: 'Chip', color:'Yellow', x: 2, y: 5},
		5: {type: 'Chip', color:'Yellow', x: 3, y: 4},
		6: {type: 'Chip', color:'Yellow', x: 4, y: 3},
		7: {type: 'Chip', color:'Yellow', x: 5, y: 2},
		8: {type: 'Chip', color:'Red', x: 2, y: 3},
		9: {type: 'Chip', color:'Red', x: 3, y: 2},
		10: {type: 'Chip', color:'Red', x: 4, y: 1},
		11: {type: 'Chip', color:'Red', x: 3, y: 5},
		12: {type: 'Chip', color:'Red', x: 4, y: 4},
		13: {type: 'Chip', color:'Red', x: 5, y: 3},
		14: {type: 'Queen', color:'Blue', x: 3, y: 0},
		15: {type: 'Queen', color:'Yellow', x: 3, y: 7},
	},
	name: '2 Spieler - Dame - Level 10',
	description: 'Schräge Reihen, wie schlage ich mich da wohl durch?',
	win : 2
}